﻿import MetaTrader5 as mt5
import statistics
from datetime import datetime
mt5.initialize()
rates = mt5.copy_rates_range("XAUUSDc", mt5.TIMEFRAME_M5, datetime(2026,8,11,10,0), datetime(2026,8,11,12,0))
if rates is not None:
    trs = []
    prev=None
    for r in rates:
        h,l,c = float(r["high"]), float(r["low"]), float(r["close"])
        tr = h-l
        if prev is not None:
            tr = max(h-l, abs(h-prev), abs(l-prev))
        trs.append(tr)
        prev=c
    def atr14(trs):
        if len(trs)<14: return statistics.mean(trs)
        return sum(trs[-14:])/14
    for i in range(len(rates)):
        if i < 6: continue
        t = datetime.fromtimestamp(int(r["time"])).strftime("%H:%M")
        seg = rates[max(0,i-13):i+1]
        atr = sum(float(r["high"])-float(r["low"]) for r in seg)/len(seg)
        print("%s TR:%.2f ATR14:%.2f  emergency1.5=%.2f  SLjarak=14.43" % (t, tr, atr, atr*1.5))
# calculate true ATR via list
trs=[]; prev=None
for r in rates:
    h,l,c = float(r["high"]), float(r["low"]), float(r["close"])
    tr = h-l
    if prev is not None:
        tr = max(h-l, abs(h-prev), abs(l-prev))
    trs.append(tr); prev=c
print()
for i,t in [(i, datetime.fromtimestamp(int(r["time"])).strftime("%H:%M")) for i,r in enumerate(rates)]:
    pass
for i in range(20, len(rates)):
    t = datetime.fromtimestamp(int(rates[i]["time"])).strftime("%H:%M")
    atr = sum(trs[i-13:i+1])/(14 if i>=13 else i+1)
    print("%s ATR14:%.2f -> emergency(1.5x) $%.2f | price-stop %.2f" % (t, atr, atr*1.5, 4405.153))
mt5.shutdown()
