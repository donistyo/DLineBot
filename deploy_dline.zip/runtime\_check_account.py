import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import MetaTrader5 as mt5
from app.mt5.session import MT5Session

MT5Session.ensure_connection()

info = mt5.account_info()
print(f"Login: {info.login}")
print(f"Balance: {info.balance}")
print(f"Equity: {info.equity}")
print(f"Margin: {info.margin}")
print(f"Free Margin: {info.margin_free}")
print(f"Server: {info.server}")
print(f"Currency: {info.currency}")

# Check if any signals/copy trading
print(f"\nTrade allowed: {info.trade_allowed}")
print(f"Trade expert: {info.trade_experts_enabled}")

# Check last trades
from datetime import datetime, timedelta
from_today = datetime.now() - timedelta(hours=48)
deals = mt5.history_deals_get(from_today, datetime.now())
if deals:
    print(f"\nLast {min(5, len(deals))} deals:")
    for d in deals[-5:]:
        print(f"  ticket={d.ticket} time={d.time} type={'BUY' if d.type==0 else 'SELL'} vol={d.volume} price={d.price} profit={d.profit:.1f} comment={d.comment}")
