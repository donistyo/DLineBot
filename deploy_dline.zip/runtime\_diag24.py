﻿import MetaTrader5 as mt5
from datetime import datetime, timedelta

mt5.initialize()
now = datetime.now()
start = now - timedelta(hours=24)

entry_names = {0:"IN", 1:"OUT", 2:"INOUT", 3:"OUT_BY"}
deals = mt5.history_deals_get(start, now, group="*XAUUSD*")
if deals:
    print("=== DEALS (24 jam) ===")
    for d in deals:
        t = datetime.fromtimestamp(d.time)
        dirn = "BUY" if d.type == 0 else "SELL"
        print("  %s %s pos#%s %s @%.3f profit:$%+.2f vol:%.2f [%s]" % (
            t.strftime("%H:%M:%S"), entry_names.get(d.entry,"?"), d.position_id, dirn, d.price, d.profit, d.volume, d.comment))
    out = [d for d in deals if d.entry in (1,2,3)]
    net = sum(d.profit for d in out)
    wins = len([d for d in out if d.profit>0])
    losses = len([d for d in out if d.profit<0])
    print()
    print("OUT deals: %d  Win:%d Loss:%d  Net: $%.2f" % (len(out), wins, losses, net))
ai = mt5.account_info()
print("Balance: $%.2f  Equity: $%.2f" % (ai.balance, ai.equity))
mt5.shutdown()
