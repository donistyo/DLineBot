﻿import MetaTrader5 as mt5
from datetime import datetime, timedelta
mt5.initialize()
now = datetime.now()
start = now - timedelta(hours=1)
rates = mt5.copy_rates_from_pos("XAUUSD", mt5.TIMEFRAME_M5, 0, 40)
if rates is not None:
    print("M5 price action:")
    for r in reversed(rates[-14:]):
        t = datetime.fromtimestamp(int(r["time"])).strftime("%H:%M")
        print("  %s O:%.2f H:%.2f L:%.2f C:%.2f" % (t, r["open"], r["high"], r["low"], r["close"]))
mt5.shutdown()
