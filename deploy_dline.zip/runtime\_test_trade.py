import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app.mt5.session import MT5Session
from app.mt5.order_sender import OrderSender
from app.mt5.order_builder import OrderBuilder
from app.mt5.order_validator import OrderValidator

MT5Session.ensure_connection()

# Test 1: Does the validator reject SL=0?
order = OrderBuilder.sell("XAUUSDc", 0.01, 4067.0, 0.0, 0.0)
print("Order:", order)
validation = OrderValidator.validate(order)
print("Validator result:", validation)

# Test 2: What happens with send?
sender = OrderSender(dry_run=False)
result = sender.send(order)
print("Send result:", result)
