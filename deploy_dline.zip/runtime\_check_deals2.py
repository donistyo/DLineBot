import json
d = json.load(open("runtime/overview.json"))
deals = d.get("today_deals", [])
for x in deals:
    if x["time"] >= "20:00":
        print(f"{x['time']} {x['type']} {x['volume']} profit={x['profit']} comment={x.get('comment','')}")
