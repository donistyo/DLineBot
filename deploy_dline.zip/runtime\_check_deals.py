﻿import MetaTrader5 as mt5
from datetime import datetime, timedelta

mt5.initialize()
now = datetime.now()
today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

deals = mt5.history_deals_get(today_start, now, group="*XAUUSD*")
if deals:
    bot_entries = [d for d in deals if d.entry == 1 and d.comment and "DLineBot" in str(d.comment)]
    bot_exits = [d for d in deals if d.entry == 0 and d.comment and "DLineBot" in str(d.comment)]
    all_entries = [d for d in deals if d.entry == 1]
    
    print("=== TODAY DEALS ===")
    for d in all_entries:
        t = datetime.fromtimestamp(d.time)
        direction = "BUY" if d.type == 0 else "SELL"
        print("  %s %s @%.3f Vol:%.2f Profit:$%.2f [%s]" % (t.strftime("%H:%M"), direction, d.price, d.volume, d.profit, d.comment))
    
    print()
    total = sum(d.profit for d in bot_entries)
    wins = len([d for d in bot_entries if d.profit > 0])
    losses = len([d for d in bot_entries if d.profit < 0])
    print("Bot trades: %d  Wins: %d  Losses: %d  Net: $%.2f" % (len(bot_entries), wins, losses, total))

mt5.shutdown()
