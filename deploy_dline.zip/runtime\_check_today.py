import json
d = json.load(open("runtime/overview.json"))
deals = d.get("today_deals", [])
auto = [x for x in deals if x.get("volume") == 0.01]
win = sum(1 for x in auto if x["profit"] > 0)
loss = sum(1 for x in auto if x["profit"] < 0)
be = sum(1 for x in auto if x["profit"] == 0)
print(f"Auto trades: {len(auto)} | Win: {win} Loss: {loss} BE: {be}")
print(f"PnL: {sum(x['profit'] for x in auto):.2f}")
print(f"Balance: {d.get('balance')}")
print(f"Open positions: {d.get('open_count')}")
