from pathlib import Path
from datetime import datetime
import pandas as pd

from app.core.logger import logger


class DatasetManager:
    """
    Menyimpan dataset hasil collector + indicator
    """

    def __init__(self):

        self.dataset_path = Path("datasets")

        self.dataset_path.mkdir(
            exist_ok=True
        )

    def save(
        self,
        df: pd.DataFrame,
        symbol: str,
        timeframe: str,
    ) -> str:

        filename = f"{symbol}_{timeframe}.csv"

        file_path = self.dataset_path / filename

        df.to_csv(
            file_path,
            index=False
        )

        logger.info(
            f"Dataset disimpan : {file_path}"
        )

        return str(file_path)

    def load(
        self,
        symbol: str,
        timeframe: str,
    ) -> pd.DataFrame:

        filename = f"{symbol}_{timeframe}.csv"

        file_path = self.dataset_path / filename

        if not file_path.exists():
            raise FileNotFoundError(file_path)

        logger.info(
            f"Membaca dataset : {file_path}"
        )

        return pd.read_csv(
            file_path,
            parse_dates=["time"]
        )

    def list_dataset(self):

        return list(
            self.dataset_path.glob("*.csv")
        )

    def info(self, df):
        """
        Menampilkan informasi dataset.
        """

        print("=" * 40)
        print("Dataset Information")
        print("=" * 40)

        print(f"Rows    : {len(df)}")
        print(f"Columns : {len(df.columns)}")

        print("\nData Types:")
        print(df.dtypes)

        print("=" * 40)