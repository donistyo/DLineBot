﻿import MetaTrader5 as mt5
from datetime import datetime, timedelta
mt5.initialize()
now = datetime.now()
start = now.replace(hour=0, minute=0, second=0, microsecond=0)
entry_names = {0:"IN", 1:"OUT", 2:"INOUT", 3:"OUT_BY"}
deals = mt5.history_deals_get(start, now, group="*XAUUSD*")
if deals:
    print("=== DEALS HARI INI ===")
    for d in deals:
        t = datetime.fromtimestamp(d.time)
        dirn = "BUY" if d.type == 0 else "SELL"
        print("%s pos#%s %s @%.3f profit:$%+.2f [%s]" % (t.strftime("%H:%M:%S"), d.position_id, dirn, d.price, d.profit, d.comment))
    print()
    out = [d for d in deals if d.entry in (1,2,3)]
    for pos_id in sorted(set(d.position_id for d in deals if d.entry==0)):
        ins = [d for d in deals if d.position_id==pos_id and d.entry==0]
        outs = [d for d in deals if d.position_id==pos_id and d.entry in (1,2,3)]
        if ins:
            net = sum(d.profit for d in outs)
            print("  => %s @%.3f  net: $%+.2f" % ("BUY" if ins[0].type==0 else "SELL", ins[0].price, net))
    net = sum(d.profit for d in out)
    wins = len([d for d in out if d.profit>0])
    losses = len([d for d in out if d.profit<0])
    print()
    print("Total OUT: %d  Win:%d Loss:%d  Net: $%.2f" % (len(out), wins, losses, net))
ai = mt5.account_info()
print("Balance: $%.2f  Equity: $%.2f" % (ai.balance, ai.equity))
mt5.shutdown()
