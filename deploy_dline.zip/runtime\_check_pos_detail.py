import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import MetaTrader5 as mt5
from app.mt5.session import MT5Session
MT5Session.ensure_connection()
pos = mt5.positions_get(symbol="XAUUSDc")
for p in (pos or []):
    t = "BUY" if p.type == 0 else "SELL"
    print(f"ticket={p.ticket} type={t} vol={p.volume} entry={p.price_open:.3f} current={p.price_current:.3f} profit={p.profit:.1f} sl={p.sl} tp={p.tp} comment={p.comment} magic={p.magic}")
print(f"Total: {len(pos) if pos else 0}")
