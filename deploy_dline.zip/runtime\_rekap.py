﻿import MetaTrader5 as mt5
from datetime import datetime, timedelta

mt5.initialize()

now = datetime.now()
start = now - timedelta(days=31)

deals = mt5.history_deals_get(start, now, group="*XAUUSD*")
if not deals:
    print("No deals found")
    mt5.shutdown()
    exit()

entries = [d for d in deals if d.entry == 1]
bot_entries = [d for d in entries if d.comment and "DLineBot" in str(d.comment)]
all_entry_profit = sum(d.profit for d in bot_entries)
wins = len([d for d in bot_entries if d.profit > 0])
losses = len([d for d in bot_entries if d.profit < 0])
even = len([d for d in bot_entries if d.profit == 0])

print("=== REKAP AUTOTRADE XAU (`160040915`) 30 HARI ===")
print("Periode: %s - %s" % (start.strftime("%d/%m %H:%M"), now.strftime("%d/%m %H:%M")))
print("Total bot trades: %d" % len(bot_entries))
print("Win: %d  Loss: %d  Even: %d" % (wins, losses, even))
ttl = len(bot_entries)
if ttl:
    print("Win rate: %.1f%%" % (100.0 * wins / ttl))
print("Net profit: $%.2f" % all_entry_profit)
print()
print("--- RINCIAAN ---")
for d in sorted(bot_entries, key=lambda x: x.time):
    t = datetime.fromtimestamp(d.time)
    direction = "BUY" if d.type == 0 else "SELL"
    print("  %s %s @%.3f lot:%.2f profit:$%.2f" % (t.strftime("%d/%m %H:%M"), direction, d.price, d.volume, d.profit))
mt5.shutdown()
