import json, os
d = json.load(open("runtime/overview.json"))
print("Open positions:", d.get("open_count", 0))
print("Signal:", d.get("signal"), "Conf:", d.get("confidence"))

# Check last few today_deals for SL pattern
for x in d.get("today_deals", [])[-5:]:
    print(f"{x['time']} {x['type']} {x['volume']} p={x['profit']} comment={x.get('comment','')}")

# Check close_trace
if os.path.exists("runtime/close_trace.log"):
    print("\n=== CLOSE TRACE ===")
    with open("runtime/close_trace.log") as f:
        print(f.read())
else:
    print("\nclose_trace.log not found")
