﻿import MetaTrader5 as mt5
from datetime import datetime
mt5.initialize()
rates = mt5.copy_rates_range("XAUUSDc", mt5.TIMEFRAME_M5, datetime(2026,8,11,7,20), datetime(2026,8,11,8,0))
if rates is not None:
    print("M5 candles (07:20-08:00):")
    for r in rates:
        t = datetime.fromtimestamp(int(r["time"])).strftime("%H:%M")
        print("%s O:%.2f H:%.2f L:%.2f C:%.2f" % (t, r["open"], r["high"], r["low"], r["close"]))
mt5.shutdown()
