from __future__ import annotations

import pandas as pd
import MetaTrader5 as mt5

from app.mt5.session import MT5Session
from app.utils.timeframe import get_timeframe
from app.core.logger import logger


class Collector:

    def load(
        self,
        symbol="XAUUSD",
        timeframe="H1",
        bars=1000,
    ):

        logger.info(
            f"Load data | Symbol={symbol} | TF={timeframe} | Bars={bars}"
        )

        # Pastikan koneksi masih aktif
        MT5Session.ensure_connection()

        # Aktifkan symbol
        if not mt5.symbol_select(symbol, True):
            raise RuntimeError(
                f"Symbol {symbol} tidak ditemukan."
            )

        tf = get_timeframe(timeframe)

        rates = mt5.copy_rates_from_pos(
            symbol,
            tf,
            0,
            bars
        )

        if rates is None:
            raise RuntimeError(
                f"Tidak ada data {symbol}"
            )

        df = pd.DataFrame(rates)

        df["time"] = pd.to_datetime(
            df["time"],
            unit="s"
        )

        logger.info(
            f"Berhasil mengambil {len(df)} candle."
        )

        return df