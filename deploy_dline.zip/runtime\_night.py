﻿import MetaTrader5 as mt5
from datetime import datetime, timedelta
mt5.initialize()
pos = mt5.positions_get(symbol="XAUUSDc")
print("=== OPEN ===")
if pos:
    for p in pos:
        print("pos#%s %s @%.3f SL:%.3f TP:%.3f profit:%.2f lot:%.2f swap:%.2f" % (p.ticket, "BUY" if p.type==0 else "SELL", p.price_open, p.sl, p.tp, p.profit, p.volume, p.swap))
else:
    print("tidak ada posisi open")
now = datetime.now()
start = now - timedelta(hours=20)
entry_names = {0:"IN", 1:"OUT", 2:"INOUT", 3:"OUT_BY"}
deals = mt5.history_deals_get(start, now, group="*XAUUSD*")
print()
print("=== DEALS 20 jam ===")
if deals:
    for d in deals:
        t = datetime.fromtimestamp(d.time)
        dirn = "BUY" if d.type == 0 else "SELL"
        print("%s pos#%s %s @%.3f profit:$%+.2f [%s]" % (t.strftime("%H:%M:%S"), d.position_id, dirn, d.price, d.profit, d.comment))
mt5.shutdown()
