import json
d = json.load(open("runtime/overview.json"))
deals = d.get("today_deals", [])
for x in deals[-8:]:
    print(f"{x['time']} {x['type']} {x['volume']} profit={x['profit']} ticket={x['ticket']}")
print(f"--- {d.get('trades_today',0)} trades, {d.get('profit_today',0)} profit, {d.get('open_count',0)} open")
