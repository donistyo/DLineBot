import json
d = json.load(open("runtime/overview.json"))
print(f"Balance: {d['balance']}, Equity: {d['equity']}, Trades: {d['trades_today']}, PnL: {d['profit_today']}")
print(f"Signal: {d.get('signal')}, Conf: {d.get('confidence')}, Trade: {d.get('trade')}")
print(f"Open: {d['open_count']}, Auto: {d.get('auto_trade_enabled', '?')}")
# check last deals
for x in d.get("today_deals", [])[-4:]:
    print(f"  {x['time']} {x['type']} {x['volume']} p={x['profit']} c={x.get('comment','')}")
