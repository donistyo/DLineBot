import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app.mt5.position_manager import PositionManager
from app.mt5.session import MT5Session

MT5Session.ensure_connection()

pm = PositionManager()
symbol = "XAUUSDc"
positions = pm.get_positions(symbol)
print(f"Open positions for {symbol}: {len(positions)}")
for p in positions:
    sl_info = f"sl={p.sl}" if p.sl else "sl=0"
    print(f"  ticket={p.ticket} type={'BUY' if p.type==0 else 'SELL'} price_open={p.price_open} current={p.price_current} profit={p.profit} {sl_info} tp={p.tp}")
