﻿import MetaTrader5 as mt5
from datetime import datetime, timedelta

mt5.initialize()
now = datetime.now()
start = now - timedelta(hours=6)
deals = mt5.history_deals_get(start, now, group="*XAUUSD*")
if deals:
    print("=== DEALS 6 JAM (ENTRY bot) ===")
    for d in deals:
        if d.entry == 1:
            t = datetime.fromtimestamp(d.time)
            dirn = "BUY" if d.type == 0 else "SELL"
            print("  %s %s @%.3f lot:%.2f profit:$%.2f [%s]" % (t.strftime("%H:%M:%S"), dirn, d.price, d.volume, d.profit, d.comment))
    print()
    print("=== SEMUA DEAL ===")
    for d in deals:
        t = datetime.fromtimestamp(d.time)
        dirn = "BUY" if d.type == 0 else "SELL"
        etype = "ENTRY" if d.entry == 1 else ("EXIT_TP" if d.entry==0 else "EXIT_SL")
        print("  %s %s %s @%.3f profit:$%.2f [%s]" % (t.strftime("%H:%M:%S"), etype, dirn, d.price, d.profit, d.comment))
else:
    print("No deals")
mt5.shutdown()
