﻿import MetaTrader5 as mt5
mt5.initialize()
pos = mt5.positions_get(symbol="XAUUSDc")
if pos:
    for p in pos:
        print("pos#%s %s @%.3f SL:%.3f profit:%.2f" % (p.ticket, "BUY" if p.type==0 else "SELL", p.price_open, p.sl, p.profit))
else:
    print("no open")
mt5.shutdown()
