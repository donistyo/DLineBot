import MetaTrader5 as mt5
import pandas as pd
from app.indicators.calculate import add_indicators

# ===============================
# Koneksi MT5
# ===============================
if not mt5.initialize():
    print("Gagal koneksi")
    quit()

symbol = "XAUUSD"

# ===============================
# Pastikan symbol tersedia
# ===============================
if not mt5.symbol_select(symbol, True):
    print(f"{symbol} tidak ditemukan")
    mt5.shutdown()
    quit()

# ===============================
# Ambil 500 candle H1
# ===============================
rates = mt5.copy_rates_from_pos(
    symbol,
    mt5.TIMEFRAME_H1,
    0,
    500
)

if rates is None:
    print("Data tidak ditemukan")
    mt5.shutdown()
    quit()

# ===============================
# Ubah menjadi DataFrame
# ===============================
df = pd.DataFrame(rates)

# Konversi waktu
df["time"] = pd.to_datetime(df["time"], unit="s")

print(df.head())
print("\nJumlah candle :", len(df))

# ===============================
# Hitung indikator
# ===============================
df = add_indicators(df)

print("\nData dengan indikator:")
print(df.tail())

# ===============================
# Tutup koneksi MT5
# ===============================
mt5.shutdown()