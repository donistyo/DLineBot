﻿import MetaTrader5 as mt5
from datetime import datetime
mt5.initialize()
sym = "XAUUSDc"
# ambil 20 bar M5 sampai jam 12:00
rates = mt5.copy_rates_range(sym, mt5.TIMEFRAME_M5, datetime(2026,8,10,11,25), datetime(2026,8,10,11,55))
trs = []
prev_close = None
lines = []
if rates is not None:
    for r in rates:
        t = datetime.fromtimestamp(int(r["time"])).strftime("%H:%M")
        h, lo, c = float(r["high"]), float(r["low"]), float(r["close"])
        tr = h - lo
        if prev_close is not None:
            tr = max(h - lo, abs(h - prev_close), abs(lo - prev_close))
        trs.append(tr)
        lines.append("%s H:%.2f L:%.2f C:%.2f TR:%.2f" % (t, h, lo, c, tr))
        prev_close = c
print("\n".join(lines))
if len(trs) >= 14:
    atr14 = sum(trs[-14:]) / 14
    print("\nATR M5 (14) @ bar terakhir: %.2f" % atr14)
    print("early_trigger = 0.65*ATR = %.2f" % (0.65*atr14))
    print("be_trigger     = 0.50*ATR = %.2f" % (0.50*atr14))
    print("SL broker pos  = 3.00 poin dari entry")
    print("Profit puncak posisi = ~1.5 poin (4336.06 vs entry 4334.588)")
mt5.shutdown()
