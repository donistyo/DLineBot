﻿import MetaTrader5 as mt5
from datetime import datetime, timedelta

mt5.initialize()
now = datetime.now()
start = now - timedelta(days=31)
deals = mt5.history_deals_get(start, now, group="*XAUUSD*")

# Ambil hanya ENTRY deals bot (entry==1, comment DLineBot)
bot = [d for d in deals if d.entry == 1 and d.comment and "DLineBot" in str(d.comment)]
# Kelompokkan per tanggal
from collections import defaultdict
by_day = defaultdict(lambda: {"p":0.0,"n":0,"w":0,"l":0})
for d in bot:
    t = datetime.fromtimestamp(d.time)
    day = t.strftime("%d/%m")
    by_day[day]["p"] += d.profit
    by_day[day]["n"] += 1
    if d.profit > 0: by_day[day]["w"] += 1
    elif d.profit < 0: by_day[day]["l"] += 1

print("=== REKAP HARIAN AUTOTRADE XAU AKUN UTAMA (30 HARI) ===")
tot_p=tot_n=tot_w=tot_l=0.0
for day in sorted(by_day):
    r = by_day[day]
    tot_p += r["p"]; tot_n += r["n"]; tot_w += r["w"]; tot_l += r["l"]
    print("  %s: %2d trade (W%d/L%d)  Net: %+8.2f" % (day, r["n"], r["w"], r["l"], r["p"]))
print()
print("TOTAL   : %d trade (W%d/L%d)  Net: %+.2f" % (tot_n, tot_w, tot_l, tot_p))

# Big losses
big = sorted([d for d in bot if d.profit < -5], key=lambda x: x.profit)
print()
print("=== 5 LOSS TERBESAR ===")
for d in big[:5]:
    t = datetime.fromtimestamp(d.time)
    direction = "BUY" if d.type==0 else "SELL"
    print("  %s %s @%.3f lot:%.2f $%+.2f" % (t.strftime("%d/%m %H:%M"), direction, d.price, d.volume, d.profit))
mt5.shutdown()
