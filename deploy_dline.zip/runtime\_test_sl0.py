import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import MetaTrader5 as mt5
from app.mt5.session import MT5Session

MT5Session.ensure_connection()

# Test: try to open a SELL 0.01 with SL=0, TP=0
symbol = "XAUUSDc"
tick = mt5.symbol_info_tick(symbol)
print(f"Bid: {tick.bid}, Ask: {tick.ask}")

request = {
    "action": mt5.TRADE_ACTION_DEAL,
    "symbol": symbol,
    "volume": 0.01,
    "type": mt5.ORDER_TYPE_SELL,
    "price": tick.bid,
    "sl": 0.0,
    "tp": 0.0,
    "deviation": 20,
    "magic": 10001,
    "comment": "DLineBot TEST SL=0",
    "type_time": mt5.ORDER_TIME_GTC,
    "type_filling": mt5.ORDER_FILLING_IOC
}

result = mt5.order_send(request)
print(f"Retcode: {result.retcode} - {result.comment}")
print(f"Result dict: {result}")
