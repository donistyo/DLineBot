from pathlib import Path
import joblib

from app.core.logger import logger


class ModelManager:
    """
    Menyimpan dan membaca model AI.
    """

    def __init__(self):

        self.model_path = Path("models")

        self.model_path.mkdir(exist_ok=True)

    def save(
        self,
        model,
        filename: str
    ) -> str:

        file = self.model_path / filename

        joblib.dump(
            model,
            file
        )

        logger.info(f"Model disimpan : {file}")

        return str(file)

    def load(
        self,
        filename: str
    ):

        file = self.model_path / filename

        if not file.exists():
            raise FileNotFoundError(file)

        logger.info(f"Load Model : {file}")

        return joblib.load(file)

    def list_models(self):

        return list(
            self.model_path.glob("*.joblib")
        )