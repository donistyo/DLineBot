import sys, os, time, json
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import MetaTrader5 as mt5
from app.mt5.session import MT5Session

MT5Session.ensure_connection()

# Check current position
symbol = "XAUUSDc"
positions = mt5.positions_get(symbol=symbol)
print(f"Open positions: {len(positions) if positions else 0}")
for p in (positions or []):
    print(f"  ticket={p.ticket} type={'BUY' if p.type==0 else 'SELL'} entry={p.price_open:.3f} current={p.price_current:.3f} profit={p.profit:.1f} sl={p.sl} tp={p.tp}")
