﻿import MetaTrader5 as mt5
from datetime import datetime, timedelta
mt5.initialize()
sym = [s for s in mt5.symbols_get() if "XAU" in s.name.upper()]
print("Symbols:", sym)
if sym:
    s = sym[0].name
    rates = mt5.copy_rates_from_pos(s, mt5.TIMEFRAME_M5, 0, 60)
    print("len rates:", len(rates) if rates is not None else None)
    if rates is not None:
        for r in rates[-14:]:
            t = datetime.fromtimestamp(int(r["time"])).strftime("%H:%M")
            print("%s O:%.2f H:%.2f L:%.2f C:%.2f" % (t, r["open"], r["high"], r["low"], r["close"]))
mt5.shutdown()
