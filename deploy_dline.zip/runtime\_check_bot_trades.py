import json
d = json.load(open("runtime/overview.json"))
deals = d.get("today_deals", [])
auto_trades = [x for x in deals if x.get("volume") == 0.01]
print(f"Total 0.01 lot trades: {len(auto_trades)}")
win = sum(1 for x in auto_trades if x["profit"] > 0)
loss = sum(1 for x in auto_trades if x["profit"] < 0)
be = sum(1 for x in auto_trades if x["profit"] == 0)
total_pnl = sum(x["profit"] for x in auto_trades)
print(f"Win: {win} Loss: {loss} BE: {be}")
print(f"Total PnL: {total_pnl:.2f}")
# show last 5
for x in auto_trades[-5:]:
    print(f"  {x['time']} {x['type']} p={x['profit']} comment={x.get('comment','')}")
print(f"\nOverall: {d.get('trades_today')} trades, {d.get('profit_today')} pnl")
print(f"Balance: {d.get('balance')}")
