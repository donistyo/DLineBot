import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import MetaTrader5 as mt5
from app.mt5.session import MT5Session

MT5Session.ensure_connection()

# Close all positions
positions = mt5.positions_get(symbol="XAUUSDc")
print(f"Open positions: {len(positions) if positions else 0}")
for p in (positions or []):
    price = mt5.symbol_info_tick(p.symbol).bid if p.type == 0 else mt5.symbol_info_tick(p.symbol).ask
    request = {
        "action": mt5.TRADE_ACTION_DEAL,
        "position": p.ticket,
        "symbol": p.symbol,
        "volume": p.volume,
        "type": mt5.ORDER_TYPE_SELL if p.type == 0 else mt5.ORDER_TYPE_BUY,
        "price": price,
        "deviation": 20,
        "magic": 10001,
        "comment": "DLineBot CLOSE",
        "type_time": mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC
    }
    result = mt5.order_send(request)
    print(f"Close ticket={p.ticket} profit={p.profit:.1f}: retcode={result.retcode}")
