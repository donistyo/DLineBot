import json
d = json.load(open("runtime/scalping.json"))
print(f"Score: {d.get('score','?')} Grade: {d.get('grade','?')} Dir: {d.get('direction','?')}")
print(f"Momentum: {d.get('momentum',{}).get('direction','?')} Speed: {d.get('speed',{}).get('level','?')}")
print(f"Action: {d.get('action','?')}")
print(d)
