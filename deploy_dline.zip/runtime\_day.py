﻿import MetaTrader5 as mt5
from datetime import datetime
mt5.initialize()
now = datetime.now()
day_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
entry_names = {0:"IN", 1:"OUT", 2:"INOUT", 3:"OUT_BY"}
deals = mt5.history_deals_get(day_start, now, group="*XAUUSD*")
if deals:
    for pos_id in sorted(set(d.position_id for d in deals if d.entry==0)):
        ins = [d for d in deals if d.position_id==pos_id and d.entry==0]
        outs = [d for d in deals if d.position_id==pos_id and d.entry in (1,2,3)]
        if ins:
            net = sum(d.profit for d in outs)
            why = " / ".join((d.comment if d.comment else "?") for d in outs)
            print("%s @%.3f  net: $%+.2f  [%s]" % ("BUY" if ins[0].type==0 else "SELL", ins[0].price, net, why))
    out = [d for d in deals if d.entry in (1,2,3)]
    net = sum(d.profit for d in out)
    wins = len([d for d in out if d.profit>0])
    losses = len([d for d in out if d.profit<0])
    print()
    print("Total: %d  Win:%d Loss:%d  Net: $%.2f" % (len(out), wins, losses, net))
    w = [d.profit for d in out if d.profit>0]; l = [d.profit for d in out if d.profit<0]
    if w: print("Avg win: $%.2f" % (sum(w)/len(w)))
    if l: print("Avg loss: $%.2f" % (sum(l)/len(l)))
ai = mt5.account_info()
print("Balance: $%.2f" % ai.balance)
mt5.shutdown()
