﻿import MetaTrader5 as mt5
from datetime import datetime, timedelta
mt5.initialize()
now = datetime.now()
day_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
entry_names = {0:"IN", 1:"OUT", 2:"INOUT", 3:"OUT_BY"}
deals = mt5.history_deals_get(day_start, now, group="*XAUUSD*")
if deals:
    wins, losses, win_amt, loss_amt = [], [], 0, 0
    for pos_id in sorted(set(d.position_id for d in deals if d.entry==0)):
        ins = [d for d in deals if d.position_id==pos_id and d.entry==0]
        outs = [d for d in deals if d.position_id==pos_id and d.entry in (1,2,3)]
        if not ins: continue
        net = sum(d.profit for d in outs)
        why = " / ".join(d.comment if d.comment else "?" for d in outs)
        print("%s @%.3f  net: $%+.2f  [%s]" % ("BUY" if ins[0].type==0 else "SELL", ins[0].price, net, why))
        if net > 0: wins.append(net); win_amt += net
        else: losses.append(net); loss_amt += net
    print()
    print("Win : %d  (avg $%.2f)" % (len(wins), win_amt/len(wins) if wins else 0))
    print("Loss: %d  (avg $%.2f)" % (len(losses), loss_amt/len(losses) if losses else 0))
    print("Total: $%.2f  (%d trades)" % (win_amt+loss_amt, len(wins)+len(losses)))
mt5.shutdown()
