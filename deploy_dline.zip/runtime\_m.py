﻿import MetaTrader5 as mt5
from datetime import datetime, timedelta
mt5.initialize()
now = datetime.now()
start = now - timedelta(hours=6)
entry_names = {0:"IN", 1:"OUT", 2:"INOUT", 3:"OUT_BY"}
deals = mt5.history_deals_get(start, now, group="*XAUUSD*")
if deals:
    for d in deals:
        t = datetime.fromtimestamp(d.time)
        dirn = "BUY" if d.type == 0 else "SELL"
        print("%s pos#%s %s @%.3f profit:$%+.2f [%s]" % (t.strftime("%H:%M:%S"), d.position_id, dirn, d.price, d.profit, d.comment))
    print()
    for pos_id in sorted(set(d.position_id for d in deals if d.entry==0)):
        ins = [d for d in deals if d.position_id==pos_id and d.entry==0]
        outs = [d for d in deals if d.position_id==pos_id and d.entry in (1,2,3)]
        if ins:
            net = sum(d.profit for d in outs)
            print("  => %s @%.3f  net: $%+.2f" % ("BUY" if ins[0].type==0 else "SELL", ins[0].price, net))
pos = mt5.positions_get(symbol="XAUUSDc")
print()
print("=== OPEN ===")
if pos:
    for p in pos:
        print("pos#%s %s @%.3f SL:%.3f profit:%.2f" % (p.ticket, "BUY" if p.type==0 else "SELL", p.price_open, p.sl, p.profit))
else:
    print("tidak ada")
mt5.shutdown()
