﻿import MetaTrader5 as mt5
from datetime import datetime, timedelta
mt5.initialize()
now = datetime.now()
start = now - timedelta(hours=2)
entry_names = {0:"IN", 1:"OUT", 2:"INOUT", 3:"OUT_BY"}
deals = mt5.history_deals_get(start, now, group="*XAUUSD*")
if deals:
    for d in deals:
        t = datetime.fromtimestamp(d.time)
        dirn = "BUY" if d.type == 0 else "SELL"
        print("%s pos#%s %s @%.3f profit:$%+.2f vol:%.2f [%s]" % (t.strftime("%H:%M:%S"), d.position_id, dirn, d.price, d.profit, d.volume, d.comment))
mt5.shutdown()
